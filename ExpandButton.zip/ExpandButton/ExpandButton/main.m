//
//  main.m
//  ExpandButton
//
//  Created by 何云东 on 2019/4/22.
//  Copyright © 2019 何云东. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
