//
//  ViewController.m
//  ExpandButton
//
//  Created by 何云东 on 2019/4/22.
//  Copyright © 2019 何云东. All rights reserved.
//

#import "ViewController.h"
#import "UIButton+LeeHitRect.h"
@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self creatExpandBtView];
    // Do any additional setup after loading the view.
}

-(void)creatExpandBtView{
    
    UIButton * testbt = [[UIButton alloc]initWithFrame:CGRectMake(100, 100, 30, 30)];
    testbt.backgroundColor = [UIColor redColor];
    testbt.hitEdgeInsets = UIEdgeInsetsMake(-30, -40, -50, -60);
    
    [testbt addTarget:self action:@selector(chlickbt) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:testbt];
    
    
}

-(void)chlickbt{
    NSLog(@"=========被点击");
}
@end
